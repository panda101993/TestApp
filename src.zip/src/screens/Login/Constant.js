export default {
    phoneNumber: '',
    phoneNumberStatus: false,
    phoneNumberError: '',
    activephoneNumberBorderError: false,

    password:"",
    passwordStatus:false,
    passwordError:'',
    activepasswordBorderColor:false,

}