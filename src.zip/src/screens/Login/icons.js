const path = '../../assets/images/'
const ext = '.png'

export default Icons ={
      
// logo: require(`${path}layer2${ext}`),
unchecked: require(`${path}checked${ext}`),
checked: require(`${path}unchecked${ext}`),

}