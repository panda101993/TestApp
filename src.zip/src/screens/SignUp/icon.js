
const path = '../../assets/images/'
const ext = '.png'

export default Icons ={
      
// logo: require(`${path}forgotpassword_icon${ext}`),
// headerimage: require(`${path}header_image${ext}`),
unchecked: require(`${path}checked${ext}`),
checked: require(`${path}unchecked${ext}`),
}