export default {
  name:"",
  nameStatus:false,
  nameError:"",
  activefirstnameBorderColor:false,

  countrycode:"",
  lastname:"",
  lastnameStatus:false,
  lastnameError:"",
  activelastnameBorderColor:false,

  phoneNumber: '',
  phoneNumberStatus: false,
  phoneNumberError: '',
  activephoneNumberBorderError: false,
          
  email:"",
  emailStatus:false,
  emailError:"",
  activeemailBorderColor:false,


  password:"",
  passwordStatus:false,
  passwordError:'',
  activepasswordBorderColor:false,

  confirmPassword:"",
  confirmPasswordStatus:false,
  confirmPasswordError:"",
  activeconfirmPasswordBorderColor:false,



  
  
 


}