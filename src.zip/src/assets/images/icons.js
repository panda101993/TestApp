
export default icons={
 nameImg : require('../assets/icon_user.png'),
 emailImg : require('../assets/icon_email.png'),
 mobileImg1 : require('../assets/icon_flag.png'),
 mobileImg2 : require('../assets/icon_mobile.png'),
 mobileImg3 : require('../assets/dd.png'),
 passwordImg : require('../assets/icon_pass.png'),
 referralImg : require('../assets/icon_otp.png'),
 logoFacebook : require( '../assets/fb.png'),
 logoGoogle : require( '../assets/google.png'),
 logoTwitter : require( '../assets/twitter.png'),
 logoInsta : require( '../assets/insta.png'),
}